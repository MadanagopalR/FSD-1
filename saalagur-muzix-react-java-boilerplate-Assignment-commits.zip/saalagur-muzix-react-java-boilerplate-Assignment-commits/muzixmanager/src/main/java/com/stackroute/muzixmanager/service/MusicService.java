package com.stackroute.muzixmanager.service;

import java.util.List;

import com.stackroute.muzixmanager.exception.MusicDoesNoteExistsException;
import com.stackroute.muzixmanager.exception.MusicNotCreatedException;
import com.stackroute.muzixmanager.exception.MusicNotFoundException;
import com.stackroute.muzixmanager.model.Music;

public interface MusicService {
	
	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    boolean createMusic(Music music) throws MusicNotCreatedException;

    boolean deleteMusic(String musicId) throws MusicDoesNoteExistsException;

    Music updateMusic(Music music, String musicId);

    Music getMusicById(String music) throws MusicNotFoundException;

    List<Music> getAllMusicByUserId(String userId);
}
