package com.stackroute.muzixmanager.service;

import java.util.List;
import java.util.Locale.Category;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.muzixmanager.exception.MusicDoesNoteExistsException;
import com.stackroute.muzixmanager.exception.MusicNotCreatedException;
import com.stackroute.muzixmanager.exception.MusicNotFoundException;
import com.stackroute.muzixmanager.model.Music;
import com.stackroute.muzixmanager.repository.MusicRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */

@Service
public class MusicServiceImpl implements MusicService {

	/*
	 * Autowiring should be implemented for the MusicRepository. (Use
	 * Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword.
	 */
	@Autowired
	private MusicRepository musicRepository;
	
	
	public MusicServiceImpl(MusicRepository MusicRepository) {
		this.musicRepository = MusicRepository;
	}

	/*
	 * This method should be used to save a new Music.Call the corresponding
	 * method of Respository interface.
	 */
	public boolean createMusic(Music Music) throws MusicNotCreatedException {

		Music createMusicSuccess = this.musicRepository.insert(Music);
		if(createMusicSuccess != null) {
			return true;
		}
		else {
			throw new MusicNotCreatedException("Music not created");
		}
	}

	/*
	 * This method should be used to delete an existing category.Call the
	 * corresponding method of Respository interface.
	 */
	public boolean deleteMusic(String musicId) throws NoSuchElementException {
		try {
			Music musicDetails = this.musicRepository.findById(musicId).get();
			if(musicDetails != null) {
				this.musicRepository.deleteById(musicId);
				return true;
			}
			else {
				throw new NoSuchElementException();
			}
		}
		catch(Exception e) {
			throw new NoSuchElementException();
		}
	}

	/*
	 * This method should be used to update a existing category.Call the
	 * corresponding method of Respository interface.
	 */
	public Music updateMusic(Music music, String musicId) {

		Optional<Music> musicDetailsOpt = this.musicRepository.findById(musicId);
		if(musicDetailsOpt.isPresent()) {
			Music musicDetails = musicDetailsOpt.get();
			if(musicDetails.getMusicId().equals(musicId)) {
				music.setMusicId(musicId);
				musicDetails = music;
				this.musicRepository.save(music);
				return musicDetails;
			}
			return musicDetails;
			
		}
		else {
			return null;
		}
	}

	/*
	 * This method should be used to get a Music by MusicId.Call the
	 * corresponding method of Respository interface.
	 */
	public Music getMusicById(String MusicId) throws MusicNotFoundException {
		try {
			Optional<Music> MusicDetails = this.musicRepository.findById(MusicId);
			if(MusicDetails.isPresent()) {
				return MusicDetails.get();
			}
			else {
				throw new NoSuchElementException();
			}
		}
		catch(Exception e) {
			throw new MusicNotFoundException("Music not found");
		}
		
	}

	/*
	 * This method should be used to get a Music by userId.Call the corresponding
	 * method of Respository interface.
	 */
	public List<Music> getAllMusicByUserId(String userId) {
		return this.musicRepository.findAllMusicByUserId(userId);
	}


}
