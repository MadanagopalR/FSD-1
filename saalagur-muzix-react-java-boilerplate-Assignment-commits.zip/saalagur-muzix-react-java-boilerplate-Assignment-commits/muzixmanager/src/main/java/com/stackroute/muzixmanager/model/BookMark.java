package com.stackroute.muzixmanager.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/*
 * Please note that this class is annotated with @Document annotation
 * @Document identifies a domain object to be persisted to MongoDB.
 *  */
@Document
public class BookMark implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	/*
	 * This class should have five fields (userId,userName,
	 * userPassword,userMobile,userAddedDate). Out of these five fields, the field
	 * userId should be annotated with @Id (This annotation explicitly specifies the
	 * document identifier). This class should also contain the getters and setters
	 * for the fields, along with the no-arg , parameterized constructor and
	 * toString method.The value of userAddedDate should not be accepted from the
	 * user but should be always initialized with the system date.
	 */
	@Id
	private String bookMarkId;
	private String userId;
	private Music music;
	private Date createOn = new Date();
	
	public BookMark() {
		
	}

	public BookMark(String bookMarkId, String userId, Music music, Date createOn) {
		this.bookMarkId = bookMarkId;
		this.userId = userId;
		this.music = music;
		this.createOn = createOn;
	}

	public String getBookMarkId() {
		return bookMarkId;
	}

	public void setBookMarkId(String bookMarkId) {
		this.bookMarkId = bookMarkId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Music getMusic() {
		return music;
	}

	public void setMusic(Music music) {
		this.music = music;
	}

	public Date getCreateOn() {
		return createOn;
	}

	public void setCreateOn(Date createOn) {
		this.createOn = createOn;
	}
	
	

	
	
	
	
}
