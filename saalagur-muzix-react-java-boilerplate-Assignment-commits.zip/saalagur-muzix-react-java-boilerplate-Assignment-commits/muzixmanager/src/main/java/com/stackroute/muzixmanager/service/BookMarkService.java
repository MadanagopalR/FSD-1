package com.stackroute.muzixmanager.service;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import com.stackroute.muzixmanager.exception.MusicDoesNoteExistsException;
import com.stackroute.muzixmanager.exception.MusicNotCreatedException;
import com.stackroute.muzixmanager.exception.MusicNotFoundException;
import com.stackroute.muzixmanager.model.BookMark;

public interface BookMarkService {
	
	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    BookMark createBookMark(BookMark bookMark) throws MusicNotCreatedException,IOException, TimeoutException;

    boolean deleteBookMark(String bookMarkId) throws MusicDoesNoteExistsException;

    BookMark updateBookMark(BookMark bookMark, String bookMarkId);

    BookMark getBookMarkById(String bookMarkId) throws MusicNotFoundException;

    List<BookMark> getAllBookMarkByUserId(String userId);
}
