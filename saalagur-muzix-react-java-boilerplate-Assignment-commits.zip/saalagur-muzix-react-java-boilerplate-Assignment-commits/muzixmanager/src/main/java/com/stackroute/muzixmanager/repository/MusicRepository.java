package com.stackroute.muzixmanager.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.stackroute.muzixmanager.model.Music;

/*
* This class is implementing the MongoRepository interface for User.
* Annotate this class with @Repository annotation
* */
@Repository
public interface MusicRepository extends MongoRepository<Music, String> {
	List<Music> findAllMusicByUserId(String userId);
}
