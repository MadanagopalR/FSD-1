package com.stackroute.muzixmanager.service;

import java.io.IOException;
import java.io.Serializable;
import java.util.concurrent.TimeoutException;

import com.stackroute.muzixmanager.model.Music;

import org.apache.commons.lang.SerializationUtils;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * The producer endpoint that writes to the queue.
 * 
 * @author syntx
 *
 */
@Component
public class Producer {

	@Autowired
	private RabbitTemplate rabbitTemplate;

	@Autowired
	private Queue queue;

	public void send(Music music){
		rabbitTemplate.convertAndSend(this.queue.getName(), music);
	}
	
}