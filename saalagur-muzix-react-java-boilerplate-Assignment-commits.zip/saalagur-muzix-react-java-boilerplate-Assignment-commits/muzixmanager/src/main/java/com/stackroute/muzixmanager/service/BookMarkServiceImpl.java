package com.stackroute.muzixmanager.service;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.muzixmanager.exception.MusicNotCreatedException;
import com.stackroute.muzixmanager.exception.MusicNotFoundException;
import com.stackroute.muzixmanager.model.BookMark;
import com.stackroute.muzixmanager.model.Music;
import com.stackroute.muzixmanager.repository.BookMarkRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */

@Service
public class BookMarkServiceImpl implements BookMarkService {

	/*
	 * Autowiring should be implemented for the MusicRepository. (Use
	 * Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword.
	 */
	@Autowired
	private BookMarkRepository bookMarkRepository;

	@Autowired
	private Producer producer;

	public BookMarkServiceImpl(BookMarkRepository bookMarkRepository) {
		this.bookMarkRepository = bookMarkRepository;
	}

	/*
	 * This method should be used to save a new Music.Call the corresponding method
	 * of Respository interface.
	 */
	public BookMark createBookMark(BookMark bookMark) throws MusicNotCreatedException, IOException, TimeoutException {

		BookMark createMusicSuccess = this.bookMarkRepository.insert(bookMark);
		if(createMusicSuccess != null) {
			bookMark.getMusic().setUserId(bookMark.getUserId());
			producer.send(bookMark.getMusic());
			return createMusicSuccess;
		}
		else {
			throw new MusicNotCreatedException("Music not created");
		}
	}

	/*
	 * This method should be used to delete an existing category.Call the
	 * corresponding method of Respository interface.
	 */
	public boolean deleteBookMark(String bookMarkId) throws NoSuchElementException {
		try {
			BookMark bookMarkDetails = this.bookMarkRepository.findById(bookMarkId).get();
			if(bookMarkDetails != null) {
				this.bookMarkRepository.deleteById(bookMarkId);
				return true;
			}
			else {
				throw new NoSuchElementException();
			}
		}
		catch(Exception e) {
			throw new NoSuchElementException();
		}
	}

	/*
	 * This method should be used to update a existing category.Call the
	 * corresponding method of Respository interface.
	 */
	public BookMark updateBookMark(BookMark bookMark, String bookMarkId) {

		Optional<BookMark> bookMarkDetailsOpt = this.bookMarkRepository.findById(bookMarkId);
		if(bookMarkDetailsOpt.isPresent()) {
			BookMark bookMarkDetails = bookMarkDetailsOpt.get();
			if(bookMarkDetails.getBookMarkId().equals(bookMarkId)) {
				bookMark.setBookMarkId(bookMarkId);
				bookMarkDetails = bookMark;
				this.bookMarkRepository.save(bookMark);
			}
			return bookMarkDetails;
			
		}
		else {
			return null;
		}
	}

	/*
 	 * corresponding method of Respository interface.
	 */
	public BookMark getBookMarkById(String bookMarkId) throws MusicNotFoundException {
		try {
			Optional<BookMark> bookMarkDetails = this.bookMarkRepository.findById(bookMarkId);
			if(bookMarkDetails.isPresent()) {
				return bookMarkDetails.get();
			}
			else {
				throw new NoSuchElementException();
			}
		}
		catch(Exception e) {
			throw new MusicNotFoundException("Book not found");
		}
		
	}

	/*
	 * This method should be used to get a Music by userId.Call the corresponding
	 * method of Respository interface.
	 */
	public List<BookMark> getAllBookMarkByUserId(String userId) {
		return this.bookMarkRepository.findAllMusicByUserId(userId);
	}


}
