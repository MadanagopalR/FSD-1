package com.stackroute.muzixmanager.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/*
 * Please note that this class is annotated with @Document annotation
 * @Document identifies a domain object to be persisted to MongoDB.
 *  */
@Document
public class PlayList {

	/*
	 * This class should have five fields (userId,userName,
	 * userPassword,userMobile,userAddedDate). Out of these five fields, the field
	 * userId should be annotated with @Id (This annotation explicitly specifies the
	 * document identifier). This class should also contain the getters and setters
	 * for the fields, along with the no-arg , parameterized constructor and
	 * toString method.The value of userAddedDate should not be accepted from the
	 * user but should be always initialized with the system date.
	 */
	@Id
	private String playListId;
	private String playListName;
	private String userId;
	private List<Music> tracks;
	private Date createOn = new Date();
	 
	public PlayList() {
		
	}

	public PlayList(String playListId,String playListName, String userId, List<Music> tracks, Date createOn) {
		super();
		this.playListId = playListId;
		this.playListName = playListName;
		this.userId = userId;
		this.tracks = tracks;
		this.createOn = createOn;
	}

	public String getPlayListId() {
		return playListId;
	}

	public void setPlayListId(String playListId) {
		this.playListId = playListId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<Music> getTracks() {
		return tracks;
	}

	public void setTracks(List<Music> tracks) {
		this.tracks = tracks;
	}

	public Date getCreateOn() {
		return createOn;
	}

	public void setCreateOn(Date createOn) {
		this.createOn = createOn;
	}

	public String getPlayListName() {
		return playListName;
	}

	public void setPlayListName(String playListName) {
		this.playListName = playListName;
	}

	

	
}
