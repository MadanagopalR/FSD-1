package com.stackroute.muzixmanager.service;

import java.util.List;

import com.stackroute.muzixmanager.exception.MusicDoesNoteExistsException;
import com.stackroute.muzixmanager.exception.MusicNotCreatedException;
import com.stackroute.muzixmanager.exception.MusicNotFoundException;
import com.stackroute.muzixmanager.model.Music;
import com.stackroute.muzixmanager.model.PlayList;

public interface PlayListService {
	
	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    boolean createPlayList(PlayList bookMark) throws MusicNotCreatedException;

    boolean deletePlayList(String bookMarkId) throws MusicDoesNoteExistsException;

    PlayList updatePlayList(Music music, String playListId);

    PlayList getPlayListById(String bookMarkId) throws MusicNotFoundException;

    List<PlayList> getAllPlayListByUserId(String userId);
}
