package com.stackroute.muzixmanager.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/*
 * Please note that this class is annotated with @Document annotation
 * @Document identifies a domain object to be persisted to MongoDB.
 *  */
@Document
public class Music implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	/*
	 * This class should have five fields (userId,userName,
	 * userPassword,userMobile,userAddedDate). Out of these five fields, the field
	 * userId should be annotated with @Id (This annotation explicitly specifies the
	 * document identifier). This class should also contain the getters and setters
	 * for the fields, along with the no-arg , parameterized constructor and
	 * toString method.The value of userAddedDate should not be accepted from the
	 * user but should be always initialized with the system date.
	 */
	@Id
	private String musicId;
	private String userId;
	private String name;
	private String link;
	private String artistName;
	private String imageUrl;
	private Date createOn = new Date();
	public Music() {
		
	}

	public Music(String musicId, String userId, String name, String link, String artistName, String imageUrl,
			Date createOn) {
		this.musicId = musicId;
		this.userId = userId;
		this.name = name;
		this.link = link;
		this.artistName = artistName;
		this.imageUrl = imageUrl;
		this.createOn = createOn;
	}

	public String getMusicId() {
		return musicId;
	}

	public void setMusicId(String musicId) {
		this.musicId = musicId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getArtistName() {
		return artistName;
	}

	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Date getCreateOn() {
		return createOn;
	}

	public void setCreateOn(Date createOn) {
		this.createOn = createOn;
	}

	

	
	
}
