package com.stackroute.muzixmanager;

import com.stackroute.muzixmanager.jwtfilter.JwtFilter;

import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.web.servlet.FilterRegistrationBean;


@SpringBootApplication
public class MuzixManagerApplication {

	@Value("${spring.rabbitmq.queue}")
	private String recqueue;
	
	/*
	 * Define the bean for Filter registration. Create a new FilterRegistrationBean
	 * object and use setFilter() method to set new instance of JwtFilter object.
	 * Also specifies the Url patterns for registration bean.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	  	@Bean
	    public FilterRegistrationBean jwtFilter() {
	       
		  final FilterRegistrationBean registrationBean = new FilterRegistrationBean();
			registrationBean.setFilter(new JwtFilter());
			registrationBean.addUrlPatterns("/api/*");
			return registrationBean;
		}
		
	public static void main(String[] args) {
		
		SpringApplication.run(MuzixManagerApplication.class, args);
	}

	@Bean
	public Queue queue(){
		return new Queue(recqueue,true);
	}
}

