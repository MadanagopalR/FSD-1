package com.stackroute.muzixmanager.service;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.muzixmanager.exception.MusicNotCreatedException;
import com.stackroute.muzixmanager.exception.MusicNotFoundException;
import com.stackroute.muzixmanager.model.Music;
import com.stackroute.muzixmanager.model.PlayList;
import com.stackroute.muzixmanager.repository.PlayListRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */

@Service
public class PlayListServiceImpl implements PlayListService {

	/*
	 * Autowiring should be implemented for the MusicRepository. (Use
	 * Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword.
	 */
	@Autowired
	private PlayListRepository playListRepository;

	public PlayListServiceImpl(PlayListRepository playListRepository) {
		this.playListRepository = playListRepository;
	}

	/*
	 * This method should be used to save a new Music.Call the corresponding method
	 * of Respository interface.
	 */
	public boolean createPlayList(PlayList playList) throws MusicNotCreatedException {
		PlayList createMusicSuccess = this.playListRepository.findPlayListByPlayListName(playList.getPlayListName());
		if (createMusicSuccess != null) {
			createMusicSuccess.getTracks().addAll(playList.getTracks());
			this.playListRepository.save(createMusicSuccess);
		} else {
			this.playListRepository.save(playList);
		}
		return true;
	}

	/*
	 * This method should be used to delete an existing category.Call the
	 * corresponding method of Respository interface.
	 */
	public boolean deletePlayList(String playListId) throws NoSuchElementException {
		try {
			PlayList playListDetails = this.playListRepository.findById(playListId).get();
			if (playListDetails != null) {
				this.playListRepository.deleteById(playListId);
				return true;
			} else {
				throw new NoSuchElementException();
			}
		} catch (Exception e) {
			throw new NoSuchElementException();
		}
	}

	/*
	 * This method should be used to update a existing category.Call the
	 * corresponding method of Respository interface.
	 */
	public PlayList updatePlayList(Music music, String playListId) {

		Optional<PlayList> playListDetailsOpt = this.playListRepository.findById(playListId);
		if (playListDetailsOpt.isPresent()) {
			PlayList playListDetails = playListDetailsOpt.get();
			if (playListDetails.getPlayListId().equals(playListId)) {
				List<Music> list = playListDetails.getTracks();
				Iterator<Music> i = list.iterator();
 
				while(i.hasNext()) {
					Music e = i.next();
					if (e.getName().equals(music.getName()) && e.getArtistName().equals(music.getArtistName())) {
						i.remove();
					}
				}
				
				playListDetails.setTracks(list);
				this.playListRepository.save(playListDetails);
			}
			return playListDetails;

		} else {
			return null;
		}
	}

	/*
	 * corresponding method of Respository interface.
	 */
	public PlayList getPlayListById(String playListId) throws MusicNotFoundException {
		try {
			Optional<PlayList> playListDetails = this.playListRepository.findById(playListId);
			if (playListDetails.isPresent()) {
				return playListDetails.get();
			} else {
				throw new NoSuchElementException();
			}
		} catch (Exception e) {
			throw new MusicNotFoundException("Book not found");
		}

	}

	/*
	 * This method should be used to get a Music by userId.Call the corresponding
	 * method of Respository interface.
	 */
	public List<PlayList> getAllPlayListByUserId(String userId) {
		return this.playListRepository.findAllPlayListByUserId(userId);
	}


}
