package com.stackroute.muzixmanager.exception;

public class MusicDoesNoteExistsException extends Exception {

	private static final long serialVersionUID = 1L;
	public MusicDoesNoteExistsException(String message) {
        super(message);
    }
}
