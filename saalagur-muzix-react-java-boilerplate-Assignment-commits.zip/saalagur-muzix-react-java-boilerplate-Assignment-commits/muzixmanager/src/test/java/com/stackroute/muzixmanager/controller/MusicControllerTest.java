package com.stackroute.muzixmanager.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.muzixmanager.model.Music;
import com.stackroute.muzixmanager.service.BookMarkService;
import com.stackroute.muzixmanager.service.MusicService;
import com.stackroute.muzixmanager.service.PlayListService;

@RunWith(SpringRunner.class)
@WebMvcTest
public class MusicControllerTest {
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean 
    private Music music;

    @MockBean
    MusicService musicService;
    
    @MockBean
    BookMarkService bookMarkService;
    
    @MockBean
    PlayListService playListService;

    @InjectMocks
    MusicController musicController;
    
    List<Music> tracks;

    @Before
    public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(musicController).build();
        music = new Music();
        music.setArtistName("Sanjeev");
        music.setCreateOn(new Date());
        music.setMusicId("mmiiidddd");
        music.setUserId("test123");
        music.setName("Kannada Song");
        tracks = new ArrayList<>();
        tracks.add(music);

    }
    private static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    public void createMusicToDB() throws Exception {
        when(musicService.createMusic(any())).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/user/test123/music")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(music)))
        .andExpect(MockMvcResultMatchers.status().isCreated())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void createMusicToDBFail() throws Exception {
        when(musicService.createMusic(any())).thenReturn(false);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/user/test123/music")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(music)))
        .andExpect(MockMvcResultMatchers.status().isConflict())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void deleteMusicFromDB() throws Exception {
        when(musicService.deleteMusic("mmiiidddd")).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/user/test123/music/mmiiidddd")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void deleteMusicFromDFail() throws Exception {
        when(musicService.deleteMusic("mmiiidddd")).thenReturn(false);
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/user/test123/music/mmiiidddd")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void updateMusicFromDB() throws Exception {
    	when(musicService.updateMusic(any(),eq("mmiiidddd"))).thenReturn(music);
    	music.setName("Mungaru Male");
        mockMvc.perform(MockMvcRequestBuilders.put("/api/v1/user/test123/music/mmiiidddd")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(music)))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void updateMusicFromDFail() throws Exception {
        when(musicService.updateMusic(any(),eq("mmiiidddd"))).thenReturn(null);
        music.setName("Mungaru Male");
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/user/test123/music/mmiiidddd")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(music)))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void getAllMusicByIdFromDb() throws Exception {
    	when(musicService.getAllMusicByUserId(eq("test123"))).thenReturn(tracks);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/user/test123/music/getAll")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void getAllMusicByIdFromDbFail() throws Exception {
    	when(musicService.getAllMusicByUserId(eq("test123"))).thenReturn(null);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/user/test123/music/getAll")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
}