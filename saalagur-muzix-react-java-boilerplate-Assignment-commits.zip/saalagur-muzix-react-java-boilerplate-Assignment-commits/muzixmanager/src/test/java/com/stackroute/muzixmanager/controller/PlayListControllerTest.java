package com.stackroute.muzixmanager.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.muzixmanager.model.Music;
import com.stackroute.muzixmanager.model.PlayList;
import com.stackroute.muzixmanager.service.BookMarkService;
import com.stackroute.muzixmanager.service.MusicService;
import com.stackroute.muzixmanager.service.PlayListService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@RunWith(SpringRunner.class)
@WebMvcTest
public class PlayListControllerTest {
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private PlayList playList;

    @MockBean 
    private Music music;

    @MockBean
    MusicService musicService;
    
    @MockBean
    BookMarkService bookMarkService;
    
    @MockBean
    PlayListService playListService;

    @InjectMocks
    PlayListController playListController;

    private List<Music> tracks;
    
    private List<PlayList> playlists;

    @Before
    public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(playListController).build();
        playList = new PlayList();
        playList.setPlayListId("playList1");
        playList.setPlayListName("MyList1");
        playList.setCreateOn(new Date());

        music = new Music();
        music.setArtistName("Sanjeev");
        music.setCreateOn(new Date());
        music.setMusicId("mmiiidddd");
        music.setUserId("test123");
        music.setName("Kannada Song");

        tracks = new ArrayList<Music>();
        tracks.add(music);
        playList.setTracks(tracks);
        
        playlists = new ArrayList<>();
        playlists.add(playList);
    }
    private static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    public void createPlayListToDB() throws Exception {
        when(playListService.createPlayList(any())).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/user/test123/playlist").contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(playList)))
        .andExpect(MockMvcResultMatchers.status().isCreated())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void createPlayListToDBFail() throws Exception {
        when(playListService.createPlayList(any())).thenReturn(false);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/user/test123/playlist").contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(playList)))
        .andExpect(MockMvcResultMatchers.status().isConflict())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void deletePlayListFromDB() throws Exception {
        when(playListService.deletePlayList(eq("playList1"))).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/user/test123/playlist/playList1")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void deletePlayListFromDBFail() throws Exception {
        when(playListService.deletePlayList(eq("playList1"))).thenReturn(false);
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/user/test123/playlist/playList1")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void updatePlayListFromDB() throws Exception {
        when(playListService.updatePlayList(any(),eq("playList1"))).thenReturn(playList);
        playList.setPlayListName("playList2");
        mockMvc.perform(MockMvcRequestBuilders.put("/api/v1/user/test123/playlist/playList1")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(playList)))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void updatePlayListFromDBFail() throws Exception {
        when(playListService.updatePlayList(any(),eq("playList1"))).thenReturn(null);
        mockMvc.perform(MockMvcRequestBuilders.put("/api/v1/user/test123/playlist/playList1")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(playList)))
        .andExpect(MockMvcResultMatchers.status().isConflict())
        .andDo(MockMvcResultHandlers.print());
    }
    
    
    @Test
    public void getAllPlayListsByUserIdFromDb() throws Exception {
        when(playListService.getAllPlayListByUserId(eq("test123"))).thenReturn(playlists);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/user/test123/playlists")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void getAllPlayListsByUserIdFromDbFail() throws Exception {
        when(playListService.getAllPlayListByUserId(eq("test123"))).thenReturn(null);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/user/test123/playlist/playList1")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void getAllPlayListByIdFromDb() throws Exception {
        when(playListService.getPlayListById(eq("playList1"))).thenReturn(playList);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/user/test123/playlist/playList1")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void getAllPlayListByIdFromDbFail() throws Exception {
        when(playListService.getAllPlayListByUserId(eq("playList1"))).thenReturn(null);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/user/test123/playlist/playList1")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
    
}