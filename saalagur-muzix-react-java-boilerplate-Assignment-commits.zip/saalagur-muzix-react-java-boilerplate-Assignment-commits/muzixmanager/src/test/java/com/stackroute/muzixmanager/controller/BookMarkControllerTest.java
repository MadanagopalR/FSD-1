package com.stackroute.muzixmanager.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.muzixmanager.model.BookMark;
import com.stackroute.muzixmanager.model.Music;
import com.stackroute.muzixmanager.service.BookMarkService;
import com.stackroute.muzixmanager.service.MusicService;
import com.stackroute.muzixmanager.service.PlayListService;

@RunWith(SpringRunner.class)
@WebMvcTest
public class BookMarkControllerTest {
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private BookMark bookMark;

    @MockBean 
    private Music music;

    @MockBean
    MusicService musicService;
    
    @MockBean
    BookMarkService bookMarkService;
    
    @MockBean
    PlayListService playListService;

    @InjectMocks
    BookMarkController bookMarkController;
    
    List<BookMark> bookMarks;
    @Before
    public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(bookMarkController).build();
        bookMark = new BookMark();
        bookMark.setBookMarkId("bm0001");
        bookMark.setCreateOn(new Date());
        bookMark.setUserId("test123");
        music = new Music();
        music.setArtistName("Sanjeev");
        music.setCreateOn(new Date());
        music.setMusicId("mmiiidddd");
        music.setUserId("test123");
        music.setName("Kannada Song");
        bookMark.setMusic(music);
        
        bookMarks = new ArrayList<>();
        bookMarks.add(bookMark);

    }
    private static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    public void createMusicToDB() throws Exception {
        when(bookMarkService.createBookMark(any())).thenReturn(bookMark);
        mockMvc.perform(post("/api/v1/user/test123/bookmark")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(bookMark)))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void createMusicToDBFail() throws Exception {
        when(bookMarkService.createBookMark(any())).thenReturn(null);
        mockMvc.perform(post("/api/v1/user/test123/bookmark")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(bookMark)))
        .andExpect(MockMvcResultMatchers.status().isConflict())
        .andDo(MockMvcResultHandlers.print());
    }
    @Test
    public void deleteBookMarkDB() throws Exception {
        when(bookMarkService.deleteBookMark(eq("bm0001"))).thenReturn(true);
        mockMvc.perform(delete("/api/v1/user/test123/bookmark/bm0001")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(bookMark)))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void deleteBookMarkDBFail() throws Exception {
        when(bookMarkService.deleteBookMark(eq("bm0001"))).thenReturn(false);
        mockMvc.perform(delete("/api/v1/user/test123/bookmark/bm0001")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(bookMark)))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void updateeBookMarkDB() throws Exception {
    	bookMark.setCreateOn(new Date());
        when(bookMarkService.updateBookMark(any(),eq("bm0001"))).thenReturn(bookMark);
        mockMvc.perform(put("/api/v1/user/test123/bookmark/bm0001")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(bookMark)))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void updateBookMarkDBFail() throws Exception {
        when(bookMarkService.updateBookMark(any(),eq("bm0001"))).thenReturn(null);
        mockMvc.perform(put("/api/v1/user/test123/bookmark/bm0001")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(bookMark)))
        .andExpect(MockMvcResultMatchers.status().isConflict())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void getAllBookMarkByIdFromDb() throws Exception {
    	bookMark.setCreateOn(new Date());
        when(bookMarkService.getAllBookMarkByUserId(eq("test123"))).thenReturn(bookMarks);
        mockMvc.perform(get("/api/v1/user/test123/bookmark/getAll")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void getAllBookMarkByIdFromDbFail() throws Exception {
        when(bookMarkService.getAllBookMarkByUserId(eq("test123"))).thenReturn(null);
        mockMvc.perform(get("/api/v1/user/test123/bookmark/getAll")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
}