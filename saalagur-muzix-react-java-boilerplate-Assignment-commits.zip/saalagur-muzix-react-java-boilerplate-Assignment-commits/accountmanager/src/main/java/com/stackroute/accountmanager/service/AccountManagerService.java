package com.stackroute.accountmanager.service;

import com.stackroute.accountmanager.exception.AccountAlreadyExistsException;
import com.stackroute.accountmanager.exception.AccountNotFoundException;
import com.stackroute.accountmanager.model.Account;

public interface AccountManagerService {

    	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    public Account findByUserIdAndPassword(String userId, String password) throws AccountNotFoundException;
    boolean saveUser(Account account) throws AccountAlreadyExistsException;
}
