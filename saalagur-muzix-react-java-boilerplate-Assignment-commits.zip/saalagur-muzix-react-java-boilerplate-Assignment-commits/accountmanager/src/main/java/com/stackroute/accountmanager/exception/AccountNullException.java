package com.stackroute.accountmanager.exception;

public class AccountNullException extends Exception {
	private static final long serialVersionUID = 1L;
    public AccountNullException(String message) {
        super(message);
    }
}
