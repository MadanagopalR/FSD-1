package com.stackroute.accountmanager.repository;

import java.util.Date;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.stackroute.accountmanager.model.Account;



@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class AccountManagerRepositoryTest {

    @Autowired
    private AccountRepository autheticationRepository;

    private Account account;


    @Before
    public void setUp() throws Exception {
        account = new Account();
        account.setUserId("Jhon123");
        account.setFirstName("Jhon123");
        account.setLastName("Smith");
        account.setUserRole("Admin");
        account.setUserPassword("123456");
        account.setUserAddedDate(new Date());
    }

    @After
    public void tearDown() throws Exception {
        autheticationRepository.deleteAll();
    }

    @Test
    @Ignore
    public void testRegisterUserSuccess() {
        autheticationRepository.save(account);
        Account object = autheticationRepository.findById(account.getUserId()).get();
        Assert.assertEquals(account.getUserId(), object.getUserId());
    }

    @Test
    @Ignore
    public void testLoginUserSuccess() {
        autheticationRepository.save(account);
        Account object = autheticationRepository.findById(account.getUserId()).get();
        Assert.assertEquals(account.getUserId(), object.getUserId());
    }
}
