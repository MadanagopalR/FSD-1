package com.stackroute.accountmanager.service;

import java.util.Date;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.stackroute.accountmanager.exception.AccountAlreadyExistsException;
import com.stackroute.accountmanager.exception.AccountNotFoundException;
import com.stackroute.accountmanager.model.Account;
import com.stackroute.accountmanager.repository.AccountRepository;

public class AccountManagerServiceTest {

    @Mock
    private AccountRepository autheticationRepository;

    private Account user;
    @InjectMocks
    private AccountManagerServiceImpl authenticationService;

    Optional<Account> optional;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        user = new Account();
        user.setUserId("Jhon123");
        user.setFirstName("Jhon123");
        user.setLastName("Smith");
        user.setUserRole("Admin");
        user.setUserPassword("123456");
        user.setUserAddedDate(new Date());
        optional = Optional.of(user);
    }

    @Test
    public void testSaveUserSuccess() throws AccountAlreadyExistsException {

        Mockito.when(autheticationRepository.save(user)).thenReturn(user);
        boolean flag = authenticationService.saveUser(user);
        Assert.assertEquals("Cannot Register User", true, flag);

    }


    @Test(expected = AccountAlreadyExistsException.class)
    @Ignore
    public void testSaveUserFailure() throws AccountAlreadyExistsException {

        Mockito.when(autheticationRepository.findById("Jhon123")).thenReturn(optional);
        Mockito.when(autheticationRepository.save(user)).thenReturn(user);
        boolean flag = authenticationService.saveUser(user);
        Assert.assertEquals("Cannot Register User", true, flag);

    }

    @Test
    public void testFindByUserIdAndPassword() throws AccountNotFoundException {
        Mockito.when(autheticationRepository.findByUserIdAndUserPassword("Jhon123", "123456")).thenReturn(user);
        Account fetchedUser = authenticationService.findByUserIdAndPassword("Jhon123", "123456");
        Assert.assertEquals("Jhon123", fetchedUser.getUserId());
    }
}
