package com.stackroute.muzixrecommendersystem.controller;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.stackroute.muzixrecommendersystem.model.Recommendation;
import com.stackroute.muzixrecommendersystem.service.MusicService;

@RunWith(SpringRunner.class)
@WebMvcTest
public class MusicRecControllerTest {
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    Recommendation recommendation;
    
    @InjectMocks
    MusicRecController musicRecController;
    
    @MockBean
    MusicService musicService;
    
    List<Recommendation> recommendations;
    @Before
    public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(musicRecController).build();
		recommendation = new Recommendation();
		recommendation.setArtistName("Sanjeev");
		recommendation.setCreateOn(new Date());
		recommendation.setMusicId("mmiiidddd");
		recommendation.setUserId("test123");
		recommendation.setName("Kannada Song");
		recommendations = new ArrayList<>();
		recommendations.add(recommendation);

    }
    @Test
    public void getAllMusicByIdFromDb() throws Exception {
    	when(musicService.getAllRecommendationByUserId(eq("test123"))).thenReturn(recommendations);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/user/test123/recommendations")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(MockMvcResultHandlers.print());
    }
    
    @Test
    public void getAllMusicByIdFromDbFail() throws Exception {
    	when(musicService.getAllRecommendationByUserId(eq("test123"))).thenReturn(null);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/user/test123/recommendations")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().isNotFound())
        .andDo(MockMvcResultHandlers.print());
    }
}