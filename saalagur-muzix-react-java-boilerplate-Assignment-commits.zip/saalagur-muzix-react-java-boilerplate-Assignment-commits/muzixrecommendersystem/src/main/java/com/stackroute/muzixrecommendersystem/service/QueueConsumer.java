package com.stackroute.muzixrecommendersystem.service;

import com.stackroute.muzixmanager.model.Music;
import com.stackroute.muzixrecommendersystem.exception.MusicNotCreatedException;
import com.stackroute.muzixrecommendersystem.model.Recommendation;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * The endpoint that consumes messages off of the queue. Happens to be runnable.
 * 
 * @author syntx
 *
 */
@Component
public class QueueConsumer  {
	@Autowired
	MusicService musicService;

	@RabbitListener(queues ={"${spring.rabbitmq.queue}"})
	public void receive(@Payload Music music){
		try {
			Recommendation music2 = new Recommendation();
			music2.setArtistName(music.getArtistName());
			music2.setLink(music.getLink());
			music2.setName(music.getName());
			music2.setUserId(music.getUserId());
			musicService.createMusic(music2);
		} catch (MusicNotCreatedException e) {
			e.printStackTrace();
		}
	}
}