package com.stackroute.muzixrecommendersystem.exception;

public class MusicNotCreatedException extends Exception {
   
	private static final long serialVersionUID = 1L;
	public MusicNotCreatedException(String message) {
        super(message);
    }
}
