package com.stackroute.muzixrecommendersystem.exception;

public class MusicNotFoundException extends Exception {
   
	private static final long serialVersionUID = 1L;
	public MusicNotFoundException(String message) {
        super(message);
    }
}
