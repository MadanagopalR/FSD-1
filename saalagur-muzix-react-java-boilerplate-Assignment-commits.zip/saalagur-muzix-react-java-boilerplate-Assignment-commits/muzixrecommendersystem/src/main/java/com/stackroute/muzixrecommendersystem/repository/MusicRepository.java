package com.stackroute.muzixrecommendersystem.repository;

import java.util.List;

import com.stackroute.muzixrecommendersystem.model.Recommendation;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/*
* This class is implementing the MongoRepository interface for User.
* Annotate this class with @Repository annotation
* */
@Repository
public interface MusicRepository extends MongoRepository<Recommendation, String> {
	List<Recommendation> findAllRecommendationByUserId(String userId);
}
