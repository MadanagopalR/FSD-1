package com.stackroute.muzixrecommendersystem;

import com.stackroute.muzixrecommendersystem.jwtfilter.JwtFilter;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.web.servlet.FilterRegistrationBean;

@SpringBootApplication
@EnableRabbit
public class MuzixRecommenderSystemApplication {
	@Value("${spring.rabbitmq.queue}")
	private String recqueue;

		@Bean
	    public FilterRegistrationBean jwtFilter() {
		  final FilterRegistrationBean registrationBean = new FilterRegistrationBean();
			registrationBean.setFilter(new JwtFilter());
			registrationBean.addUrlPatterns("/api/*");
			return registrationBean;
		}
		
	public static void main(String[] args) {
		SpringApplication.run(MuzixRecommenderSystemApplication.class, args);
	}

	@Bean
	public Queue queue(){
		return new Queue(recqueue,true);
	}	

}

