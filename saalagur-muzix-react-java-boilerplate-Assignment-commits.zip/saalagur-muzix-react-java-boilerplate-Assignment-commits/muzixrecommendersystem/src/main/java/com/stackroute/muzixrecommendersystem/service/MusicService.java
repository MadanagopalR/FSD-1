package com.stackroute.muzixrecommendersystem.service;

import java.util.List;

import com.stackroute.muzixrecommendersystem.exception.MusicDoesNoteExistsException;
import com.stackroute.muzixrecommendersystem.exception.MusicNotCreatedException;
import com.stackroute.muzixrecommendersystem.model.Recommendation;

public interface MusicService {
	
	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    boolean createMusic(Recommendation music) throws MusicNotCreatedException;

    boolean deleteMusic(String musicId) throws MusicDoesNoteExistsException;

    Recommendation updateRecommendation(Recommendation music, String musicId);

    List<Recommendation> getAllRecommendationByUserId(String userId);
}
