package com.stackroute.muzixrecommendersystem.exception;

public class MusicDoesNoteExistsException extends Exception {

	private static final long serialVersionUID = 1L;
	public MusicDoesNoteExistsException(final String message) {
        super(message);
    }
}
