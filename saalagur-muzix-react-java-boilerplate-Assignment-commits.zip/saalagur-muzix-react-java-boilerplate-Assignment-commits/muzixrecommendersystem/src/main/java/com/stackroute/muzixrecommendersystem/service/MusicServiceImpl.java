package com.stackroute.muzixrecommendersystem.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import com.stackroute.muzixrecommendersystem.exception.MusicNotCreatedException;
import com.stackroute.muzixrecommendersystem.model.Recommendation;
import com.stackroute.muzixrecommendersystem.repository.MusicRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */

@Service
public class MusicServiceImpl implements MusicService {

	/*
	 * Autowiring should be implemented for the MusicRepository. (Use
	 * Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword.
	 */
	@Autowired
	private MusicRepository musicRepository;
	
	
	public MusicServiceImpl(MusicRepository MusicRepository) {
		this.musicRepository = MusicRepository;
	}

	/*
	 * This method should be used to save a new Music.Call the corresponding
	 * method of Respository interface.
	 */
	public boolean createMusic(Recommendation Music) throws MusicNotCreatedException {

		Recommendation createMusicSuccess = this.musicRepository.insert(Music);
		if(createMusicSuccess != null) {
			return true;
		}
		else {
			throw new MusicNotCreatedException("Music not created");
		}
	}

	/*
	 * This method should be used to delete an existing category.Call the
	 * corresponding method of Respository interface.
	 */
	public boolean deleteMusic(String musicId) throws NoSuchElementException {
		try {
			Recommendation musicDetails = this.musicRepository.findById(musicId).get();
			if(musicDetails != null) {
				this.musicRepository.deleteById(musicId);
				return true;
			}
			else {
				throw new NoSuchElementException();
			}
		}
		catch(Exception e) {
			throw new NoSuchElementException();
		}
	}

	/*
	 * This method should be used to update a existing category.Call the
	 * corresponding method of Respository interface.
	 */
	public Recommendation updateRecommendation(Recommendation music, String musicId) {

		Optional<Recommendation> musicDetailsOpt = this.musicRepository.findById(musicId);
		if(musicDetailsOpt.isPresent()) {
			Recommendation musicDetails = musicDetailsOpt.get();
			if(musicDetails.getMusicId().equals(musicId)) {
				music.setMusicId(musicId);
				musicDetails = music;
				this.musicRepository.save(music);
				return musicDetails;
			}
			return musicDetails;
			
		}
		else {
			return null;
		}
	}

	
	/*
	 * This method should be used to get a Music by userId.Call the corresponding
	 * method of Respository interface.
	 */
	public List<Recommendation> getAllRecommendationByUserId(String userId) {
		return this.musicRepository.findAllRecommendationByUserId(userId);
	}

	


}
