package com.stackroute.muzixrecommendersystem.controller;

import java.util.List;

import com.stackroute.muzixrecommendersystem.exception.MusicNotFoundException;
import com.stackroute.muzixrecommendersystem.model.Recommendation;
import com.stackroute.muzixrecommendersystem.service.MusicService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/*
 * As in this assignment, we are working with creating RESTful web service, hence annotate
 * the class with @RestController annotation.A class annotated with @Controller annotation
 * has handler methods which returns a view. However, if we use @ResponseBody annotation along
 * with @Controller annotation, it will return the data directly in a serialized 
 * format. Starting from Spring 4 and above, we can use @RestController annotation which 
 * is equivalent to using @Controller and @ResposeBody annotation
 * 
 * @CrossOrigin, @EnableFeignClients and @RibbonClient needs to be added 
 */

@RestController
@RequestMapping("/api/v1")
@CrossOrigin
//@EnableFeignClients
//@RibbonClient

public class MusicRecController {


	/*
	 * Autowiring should be implemented for the CategoryService. (Use
	 * Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword
	 */
	
	@Autowired
	MusicService musicService;

	public MusicRecController(MusicService musicService) {
		this.musicService = musicService;
	}

	/*
	 * Define a handler method which will create a category by reading the
	 * Serialized category object from request body and save the category in
	 * database. Please note that the careatorId has to be unique.This
	 * handler method should return any one of the status messages basis on
	 * different situations: 
	 * 1. 201(CREATED - In case of successful creation of the category
	 * 2. 409(CONFLICT) - In case of duplicate categoryId
	 *
	 * 
	 * This handler method should map to the URL "/api/v1/category" using HTTP POST
	 * method".
	 */
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("user/{userId}/recommendations")
	public ResponseEntity<String> getAllMusicByIdFromDb(@PathVariable("userId") String userId) throws MusicNotFoundException {
		try {
		
			List<Recommendation> musicList = this.musicService.getAllRecommendationByUserId(userId);
			
			if(musicList != null) {
				return new ResponseEntity(musicList,HttpStatus.OK);
			}
			else {
				return new ResponseEntity(musicList,HttpStatus.NOT_FOUND);
			}
			
			
		}
		catch(Exception e) {
			//throw new CategoryNotFoundException("Category not found");
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}	
		
	}

}
