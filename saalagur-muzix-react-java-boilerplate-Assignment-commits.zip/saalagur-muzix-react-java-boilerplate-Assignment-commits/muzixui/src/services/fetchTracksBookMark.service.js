
const handleError = response => {
    if(response.status === 404) {
        return Promise.reject(new Error('Invalid URL..'));
    } else if(response.status === 500) {
        return Promise.reject(new Error('Some internal error occurred..'));
    } else if(response.status === 401) {
        return Promise.reject(new Error('UnAuthorized User..'));
    }
    return Promise.reject(new Error('Generic Error..'));
}

const apiKey='92efee334aa40730c80e395b57d1dd04';

async function fetchTopTracks(token,currentPageNumber) {
    const url = 'http://ws.audioscrobbler.com/2.0/?method=user.getrecenttracks&user=carnagexcandy&format=json&api_key='+apiKey+"&page="+currentPageNumber;
    let headers = {};
    try {
        const response = await fetch(url,
            {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                }
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        return Promise.resolve(json.recenttracks);
    } catch (error) {
        return Promise.reject(error);
    }
}

async function fetchTracksByArtist(token,artistName) {
    const url = 'http://ws.audioscrobbler.com/2.0/?method=artist.search&artist='+artistName+'&format=json&api_key='+apiKey;
    let headers = {};
    try {
        const response = await fetch(url,
            {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                }
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        return Promise.resolve(json.results.artistmatches.artist);
    } catch (error) {
        return Promise.reject(error);
    }
}

async function fetchBookMarkAsync(url, token)  {
    try {
        const response = await fetch(url,
            {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                }
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        return Promise.resolve(json);
    } catch (error) {
        return Promise.reject(error);
    }
}


async function fetchPlayListAsync(url, token)  {
    try {
        const response = await fetch(url,
            {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                }
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        return Promise.resolve(json);
    } catch (error) {
        return Promise.reject(error);
    }
}

async function fetchRecommendations(url, token)  {
    try {
        const response = await fetch(url,
            {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                }
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        return Promise.resolve(json);
    } catch (error) {
        return Promise.reject(error);
    }
}

async function removeBookMarkAsync(url, token)  {
    try {
        const response = await fetch(url,
            {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                }
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = {};
        return Promise.resolve(json);
    } catch (error) {
        return Promise.reject(error);
    }
}


async function removeFromPlaylistDb(url,track, token)  {
    try {
        const response = await fetch(url,
            {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'content-type': 'application/json',
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                },
                body: JSON.stringify(track)
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = {};
        return Promise.resolve(json);

    } catch (error) {
        return Promise.reject(error);
    }
}

async function saveBookMarkAsync(url, dataToPost, token) {
    try {
        const response = await fetch(url,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'content-type': 'application/json',
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                },
                body: JSON.stringify(dataToPost)
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        return Promise.resolve(json);
    } catch (error) {
        return Promise.reject(error);
    }
}


async function savePlayListDb(url, dataToPost, token) {
    try {
        const response = await fetch(url,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'content-type': 'application/json',
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                },
                body: JSON.stringify(dataToPost)
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = {};
        return Promise.resolve(json);
    } catch (error) {
        return Promise.reject(error);
    }
}




async function authenticateUser(userName, password) {
    const credentials = { userId: userName, userPassword:password };
    try {
        const response = await fetch('http://localhost:8765/account-service/api/v1/auth/login',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                },
                body: JSON.stringify(credentials)
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        return Promise.resolve(json);
    } catch (error) {
        return Promise.reject(error);
    }
}

async function registerUser(userName, password,firstName,lastName) {
    const credentials = { userId: userName, userPassword:password,firstName,lastName };
    try {
        const response = await fetch('http://localhost:8765/account-service/api/v1/auth/register',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                },
                body: JSON.stringify(credentials)
            }
        );
        if (!response.ok) {
            return handleError(response);
        }
        const json = {};
        return Promise.resolve(json);
    } catch (error) {
        return Promise.reject(error);
    }
}

export { registerUser,authenticateUser, fetchTopTracks, saveBookMarkAsync,removeBookMarkAsync,fetchBookMarkAsync,fetchRecommendations,fetchTracksByArtist,fetchPlayListAsync,savePlayListDb,removeFromPlaylistDb, handleError, apiKey };