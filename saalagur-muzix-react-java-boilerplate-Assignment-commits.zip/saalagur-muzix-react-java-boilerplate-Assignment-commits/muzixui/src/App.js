import React from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import { BrowserRouter as Router, Route } from "react-router-dom";
import './App.css';
import Dashboard from './Components/dashboard/Dashboard';
import Login from './Components/login/Login';
import Register from './Components/register/Register';
import BookMark from './Components/bookMark/BookMark';
import PlayList from './Components/playList/PlayList';
import Recommendation from './Components/recommendation/Recommendation';
class App extends React.Component {
  render(){
    return <div>
      <Container>
        <Row>
        </Row>
        <Router>
          <Route exact path = "/" component={Login} />
          <Route exact path="/register" component={Register} />
          <Route exact path="/dashboard" component={Dashboard} />
          <Route exact path="/bookmark" component={BookMark} />
          <Route exact path="/playlist" component={PlayList} />
          <Route exact path="/musicRecommendations" component={Recommendation} />
        </Router>        
      </Container>
    </div>
  }  
}

export default App;
 