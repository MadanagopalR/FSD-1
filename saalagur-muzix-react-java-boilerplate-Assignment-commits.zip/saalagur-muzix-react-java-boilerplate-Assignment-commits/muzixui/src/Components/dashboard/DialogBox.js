import React from 'react';
import Modal from 'react-bootstrap/Modal'
import Button from 'react-bootstrap/Button'
import Form from 'react-bootstrap/Form'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import { FormErrors } from './formErrors';
import './login.css';
class DialogBox extends React.Component {
    constructor(props) {
        super(props);
        this.totalResults = 0;
        this.state = {
            show: false,
            playListName:'',
            formErrors:{playListName:''},
            playListNameValid:false,
            formValid:false
        };
    }
    handleSave = (track) =>  {
        
        console.log("Called!!!!!!!!!");
        if(this.state.formValid){
            this.props.savePlayList(this.props.track,this.state.playListName);
            this.setState({ show:false})
        }

    };
    handleClose = () => this.setState({ show:false});
    handleShow = () => this.setState({ show:true});
    handleUserInput = (e) => {
        let name = e.target.name;
        let value = e.target.value;
        this.setState({[name]:value},() => {
            this.validateField(name,value)
        })
    }
    validateField(fieldName,value){
        let fieldValidationErrors = this.state.formErrors;
        let playListNameValid = this.state.playListNameValid;
        switch(fieldName){
            case 'playListName':
            if (value && value.length > 0) {
                playListNameValid = value.length >= 3;
                fieldValidationErrors.playListName = playListNameValid ? '' : 'is invalid';
            } else {
                fieldValidationErrors.playListName = '';
            } 
            break;
            default:
            break;
        }
        this.setState({ formErrors:fieldValidationErrors,
                        playListNameValid:playListNameValid }, this.validateForm);
    }
    validateForm(){
        this.setState({ formValid: this.state.playListNameValid});
    }
    errorClass(error){
        return(error.length === 0?'':'has-error');
    }
    render(){
        const {show} = this.state;
        const {track} = this.props;
            return (
            <>
                <Button size='sm' onClick={this.handleShow}><span>&#43;</span></Button>
                <Modal show={show} onHide={this.handleClose} animation={true}>
                <Modal.Header closeButton>
                    <Modal.Title>Add to playlist</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                <Form>
                <FormErrors formErrors = {this.state.formErrors} data-type="formError" />
                    <Form.Group as={Row}>
                        <Form.Label className="formLabel" column sm="4">
                        Play List : 
                        </Form.Label>
                        <Col sm="8">
                        <Form.Control required type="text" placeholder="Name" name="playListName" onChange = {this.handleUserInput} />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} controlId="trackName">
                        <Form.Label className="formLabel" column sm="4">
                        Track : 
                        </Form.Label>
                        <Col sm="8">
                        <Form.Control plaintext readOnly defaultValue={track.name} />
                        </Col>
                    </Form.Group>
                </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleClose}>
                    Close
                    </Button>
                    <Button variant="primary" onClick={this.handleSave }>
                    Save
                    </Button>
                </Modal.Footer>
                </Modal>
            </>
            );
        }
  }

  export default DialogBox;