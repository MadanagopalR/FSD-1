import React from 'react';
import CardDeck from 'react-bootstrap/CardDeck';
import Header from '../header/Header';
import Footer from '../footer/Footer'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from '../card/Card';
import Pagination from 'react-bootstrap/Pagination';


import { fetchTopTracks,saveBookMarkAsync,removeBookMarkAsync,fetchBookMarkAsync,savePlayListDb} from '../../services/fetchTracksBookMark.service';

class Dashboard extends React.Component{
    constructor(props) {
        super(props);
        this.totalResults = 0;
        this.state = {
            showModal: false,
            tracks: [],
            bookMarks: [],
            currentPageNumber: 1,
            totalPages: 1,
            itemsPerPage: 50
        };
    }
    transformAlbumData = tracks => {
        return tracks.map(track => {
            return { name: track.name, imageUrl: track.image[2]["#text"],  artistName: track.artist["#text"],link:track.url,bookMarked:track.bookMarked?true:false,text: track.name+ ' by '+track.artist["#text"]  }
        })
    }
    groupTracksRowWise = tracks => {
        let dataInRows = {};
        const remainder = (tracks.length % 3) > 0 ? 1 : 0;
        const noOfRows = Math.floor(tracks.length/3)+remainder;
        let k = 0;
        for (let i = 0;i < tracks.length;i++) {
            if (i > 0 && i % 3 === 0) {
                k++;
                this.addRow(dataInRows, tracks.slice((i-3), i), i);
            }
            if (remainder > 0 && k === (noOfRows-1)) {
                k++;
                this.addRow(dataInRows, tracks.slice(i), i+1);
            }
        }
        return dataInRows;
    }

    addRow = (dataInRows, tracks, rowIndex) => {
        const rowData = Object.assign(dataInRows, { ['row'+rowIndex]: tracks.map((album, i) => <Col key={'row-col-'+i}><Card card={album} bookMarkTrack={this.bookMarkTrack} removeBookmark ={this.removeBookmark} savePlayList={this.savePlayList} screen="dashboard"  /></Col>) });
        return rowData;
    }

    pagination = () =>{
        const { currentPageNumber } = this.state;
        const {totalPages} = this.state;
        let items = [];
        for (let number = 1; number <= 20; number++) {
        items.push(
            <Pagination.Item data-va={number} active={number == currentPageNumber}>
                {number}
            </Pagination.Item>,
        );
        }
        return items;
    
    }

    fetchAndFilterTracks(bearerToken,currentPageNumber){
        fetchTopTracks(bearerToken,currentPageNumber)
        .then(res1 => {
            let tracks = (res1 && res1.track) ? res1.track : [];
            tracks = this.transformAlbumData(tracks);
            this.totalResults = (res1 && res1["@attr"].total) ? res1["@attr"].total : 0;
            fetchBookMarkAsync('http://localhost:8765/muzix-manager/api/v1/user/'+sessionStorage.getItem("userName")+'/bookmark/getAll',bearerToken)
            .then(res => {
                if(res && res.length > 0) {
                        let localAlb = [];
                        res.forEach(function(r1, i) { 
                            if(r1.music!=null)
                                localAlb.push(r1)
                        });
                        const updatedTracts = [...tracks];
                        for (let i = 0;i < localAlb.length;i++){
                        let trackUpdated = updatedTracts.find(track1 => (localAlb[i].music.name == track1.name && localAlb[i].music.artistName == track1.artistName));
                        if(trackUpdated!= undefined)
                            trackUpdated.bookMarked = true;
                        }
                        this.setState({ tracks: updatedTracts,bookMarks: localAlb,totalPages:  res1["@attr"].totalPages,currentPageNumber })
                    }
                    else{
                        this.setState({ tracks: tracks,totalPages:  res1["@attr"].totalPages,currentPageNumber })
                    }
                    })
            .catch(error => {
                console.log('Error in fetching News Headlines:: ', error);
            })
        })
        .catch(error => {
            console.log('Error in fetching Tracks:: ', error);
        }) 
    }

    componentDidMount() {
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
            sessionStorage.setItem("authToken", bearerToken);
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        if (this.props.location && this.props.location.state && this.props.location.state.userName) {
            sessionStorage.setItem("userName", this.props.location.state.userName);
        } 
        let currentPageNumber = this.state;       
        this.fetchAndFilterTracks(bearerToken,currentPageNumber);
        
    }

    bookMarkTrack = (track) => {
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
            sessionStorage.setItem("authToken", bearerToken);
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        let bookMark = {};
        bookMark.userId = sessionStorage.getItem("userName");
        bookMark.music = track;
        saveBookMarkAsync('http://localhost:8765/muzix-manager/api/v1/user/'+bookMark.userId+'/bookmark', bookMark, bearerToken)
        .then(res => {
            const { tracks } = this.state;
            const {bookMarks} = this.state;
            const updatedTracts = [...tracks];
            const updatedbookMarks = [...bookMarks];
            const trackUpdated = updatedTracts.find(track1 => (track.name == track1.name && track.artistName == track1.artistName));
            trackUpdated.bookMarked = true;
            updatedbookMarks.push(res);
            this.setState({ tracks: updatedTracts,bookMarks:updatedbookMarks})

        })
        .catch(error => {
            console.log('Error in saving Book Mark:: ', error);
            return Promise.reject(error);
        })
    }

    removeBookmark = (track) => {
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
            sessionStorage.setItem("authToken", bearerToken);
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        const { tracks } = this.state;
        const {bookMarks} = this.state;
        const updatedTracts = [...tracks];
        const updatedbookMarks = [...bookMarks];
        const bookMarkUpdated = updatedbookMarks.find(bookMark => (track.name == bookMark.music.name && track.artistName == bookMark.music.artistName));
        removeBookMarkAsync('http://localhost:8765/muzix-manager/api/v1/user/newuser/bookmark/'+bookMarkUpdated.bookMarkId,bearerToken)
        .then(res => {
            const trackUpdated = updatedTracts.find(track1 => (track.name == track1.name && track.artistName == track1.artistName));
            trackUpdated.bookMarked = false;
            updatedbookMarks.forEach(function(r1, i) { 
                if(r1.bookMarkId==bookMarkUpdated.bookMarkId)
                    updatedbookMarks.pop(i);
            });
            this.setState({ tracks: updatedTracts,bookMarks:updatedbookMarks})
        })
    }

    handleSelect(number) {
        console.log('handle select', number.target.text);
        let selectedPage  = number.target.text;
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        this.fetchAndFilterTracks(bearerToken,selectedPage);   
    }
    filterTracksOnSearch = (searchName) =>{
        if(searchName.length>0){
        const { tracks } = this.state;
        let updatedTracts = [...tracks];
        let filArry =  updatedTracts.filter((track)=>{if(track.name.search(searchName)>=0 || track.artistName.search(searchName)>=0) return track});
        this.setState({ tracks: filArry});
        }
        else
        this.fetchAndFilterTracks(sessionStorage.getItem("authToken"),this.state.currentPageNumber);  
    }
    savePlayList = (track,playListName) =>{
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        let playList = {};
        let plTracks = [];
        playList.userId = sessionStorage.getItem("userName");
        playList.playListName = playListName;
        plTracks.push(track);
        playList.tracks = plTracks;
        savePlayListDb('http://localhost:8765/muzix-manager/api/v1/user/'+playList.userId+'/playlist', playList, bearerToken)
        .then(res => {
            
        })
        .catch(error => {
            console.log('Error in saving News Headlines:: ', error);
            return Promise.reject(error);
        })
        return true;

    }
    
    render(){
        const { tracks} = this.state;
        const rowWiseData = this.groupTracksRowWise(tracks);
        const items = this.pagination();
        return <div>
            <Container className="cardsContainer">
                <Row className = "row-header">
                        <Header filterTracksOnSearch ={this.filterTracksOnSearch.bind(this)} ></Header>
                </Row>
                <Row className = "row-body">
                <Pagination onClick={this.handleSelect.bind(this)}>
                <Pagination.First />
                <Pagination.Prev />
                {items}
                <Pagination.Next />
                <Pagination.Last />
                </Pagination>   
                </Row>  
                    <CardDeck data-foo="cardDeck" className="cardDeck">
                        {Object.keys(rowWiseData).map((rowData, i) => <Row key={'row-'+i} data-foo="cardsRow">{rowWiseData[rowData]}</Row> )}
                    </CardDeck>
                    <Row className = "row-footer">
                        <Footer></Footer>
                    </Row>
                </Container>
        </div>;
    }
}

export default Dashboard;

