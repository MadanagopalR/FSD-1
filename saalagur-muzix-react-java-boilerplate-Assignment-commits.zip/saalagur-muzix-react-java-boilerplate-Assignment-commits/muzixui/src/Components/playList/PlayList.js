import React from 'react';
import CardDeck from 'react-bootstrap/CardDeck';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import { removeFromPlaylistDb, fetchPlayListAsync} from '../../services/fetchTracksBookMark.service';
import Card from '../card/Card';
import Footer from '../footer/Footer';
import Header from '../header/Header';

class PlayList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tracks: []
        };
    }

    transformalbumsData = tracks => {
        return tracks.map(album => {
            return { title: album.name, urlToImage: album.imageUrl,  artist: album.artist.name,url:album.url,isBookMarked:true }
        })
    }

    groupalbumsRowWise = tracks => {
        let dataInRows = {};
        const remainder = (tracks.length % 3) > 0 ? 1 : 0;
        const noOfRows = Math.floor(tracks.length/3)+remainder;
        let k = 0;
        for (let i = 1;i <= tracks.length;i++) {
            if (i >= 1  && i % 3 === 0) {
                k++;
                this.addRow(dataInRows, tracks.slice((i-3), i), k);
            }
            if (remainder > 0 && k === (noOfRows-1)) {
                k++;
                this.addRow(dataInRows, tracks.slice(i-1), k);
            }
        }
        return dataInRows;
    }

    addRow = (dataInRows, tracks, rowIndex) => {
        const rowData = Object.assign(dataInRows, { ['row'+rowIndex]: tracks.map((article, i) => <Col key={'row-col-'+i}><Card card={article} {...this.props} removeFromPlaylist ={this.removeFromPlaylist} screen="playlist" /></Col>) });
        return rowData;
    }

    componentDidMount() {
        const { tracks } = this.state;
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        if (this.props.location && this.props.location.state && this.props.location.state.userName) {
            sessionStorage.setItem("userName", this.props.location.state.userName);
        }        
        if (!tracks || tracks.length === 0) {
            fetchPlayListAsync('http://localhost:8765/muzix-manager/api/v1/user/'+sessionStorage.getItem("userName")+'/playlists',bearerToken)
            .then(res => {
                if(res && res.length > 0) {
                    let localAlb = [];
                    res.forEach(function(r1, i) { 
                        if(r1.tracks.length>0){
                            r1.tracks.forEach(function(tr1,index){
                                tr1.playListName = r1.playListName;
                                tr1.playListId = r1.playListId;
                                localAlb.push(tr1);
                            })
                        }
                            
                    });
                    this.setState({ tracks: localAlb });
                }
            })
            .catch(error => {
                console.log('Error in fetching News Headlines:: ', error);
            })
        }        
    }

    removeFromPlaylist = (track) => {
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
            sessionStorage.setItem("authToken", bearerToken);
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        const { tracks } = this.state;
        const updatedTracts = [...tracks];
        removeFromPlaylistDb('http://localhost:8765/muzix-manager/api/v1/user/'+sessionStorage.getItem("userName")+'/playlist/'+track.playListId,track,bearerToken)
        .then(res => {
            const trackUpdated = updatedTracts.findIndex(track1 => (track.playListId == track1.playListId));
            updatedTracts.pop(trackUpdated);
            this.setState({ tracks: updatedTracts});
        })
    }

    render() {
        const { tracks } = this.state;
        const updatedTracts = [...tracks];
        const rowWiseData = this.groupalbumsRowWise(updatedTracts);
        return <div>
            <Container className="cardsContainer">
             <Row className = "row-header">
                <Header isReadNow={true} {...this.props} />
            </Row>
            <CardDeck data-foo="cardDeck">
                {Object.keys(rowWiseData).map((rowData, i) => <Row key={'row-'+i} data-foo="cardsRow">{rowWiseData[rowData]}</Row> )}
            </CardDeck>
            <Row className = "row-footer">
                <Footer></Footer>
            </Row>
            </Container>
        </div>;
    }
}

export default PlayList;