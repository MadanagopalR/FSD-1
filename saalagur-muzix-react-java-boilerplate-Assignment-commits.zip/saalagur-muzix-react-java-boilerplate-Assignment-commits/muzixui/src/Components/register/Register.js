import React from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import '../login/login.css';
import { FormErrors } from '../login/formErrors';
import { registerUser } from '../../services/fetchTracksBookMark.service';

class Register extends React.Component{
    constructor(){
        super();
        this.state = {
            username : '',
            password:'',
            firstName:'',
            lastName:'',
            formErrors:{username:'',password : ''},
            usernameValid:false,
            passwordValid:false,
            firstNameValid:false,
            lastNameValid:false,
            formValid:false
        }
        this.handleUserInput = this.handleUserInput.bind(this);
        this.validateField = this.validateField.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    handleUserInput = (e) => {
        let name = e.target.name;
        let value = e.target.value;
        this.setState({[name]:value},() => {
            this.validateField(name,value)
        })
    }
    validateField(fieldName,value){
        let fieldValidationErrors = this.state.formErrors;
        let usernameValid = this.state.usernameValid;
        let passwordValid = this.state.passwordValid;
        let firstNameValid = this.state.firstNameValid;
        let lastNameValid = this.state.lastNameValid;

        switch(fieldName){
            case 'firstName':
            if (value && value.length > 0) {
                firstNameValid = value.length >= 3;
                fieldValidationErrors.firstName = firstNameValid ? '' : 'is invalid';
            } else {
                fieldValidationErrors.firstName = '';
            } 
            break;
            case 'lastName':
            if (value && value.length > 0) {
                lastNameValid = value.length >= 3;
                fieldValidationErrors.lastName = lastNameValid ? '' : 'is invalid';
            } else {
                fieldValidationErrors.lastName = '';
            } 
            break;
            case 'username':
            if (value && value.length > 0) {
                usernameValid = value.length >= 3;
                fieldValidationErrors.username = usernameValid ? '' : 'is invalid';
            } else {
                fieldValidationErrors.username = '';
            } 
            break;
            case 'password':
            if (value && value.length > 0) {
                passwordValid = value.length>=6;
                fieldValidationErrors.password = passwordValid ? '' : 'is too short';
            } else {
                fieldValidationErrors.password = '';
            }                
            break;
            default:
            break;
        }
        this.setState({ formErrors:fieldValidationErrors,
                        usernameValid:usernameValid,
                    passwordValid:passwordValid }, this.validateForm);
    }
    validateForm(){
        this.setState({ formValid: this.state.usernameValid && this.state.passwordValid });
    }
    errorClass(error){
        return(error.length === 0?'':'has-error');
    }
    handleSubmit(e) {
        e.preventDefault();
        const { formValid, username, password,firstName,lastName, formErrors } = this.state;
        let fieldValidationErrors = formErrors;
        if (formValid) {
            registerUser(username, password,firstName,lastName)
            .then(res => {
                this.props.history.push('/', {});
            })
            .catch(error => {
                console.log('Error in authenticating User:: ', error);
                fieldValidationErrors.username = 'registration failed.';
                this.setState({ formErrors: fieldValidationErrors });
                return;
            });            
        } 
    }
    render(){
        return <div className="formContainer">
            <Form className = 'loginForm' onSubmit={e => this.handleSubmit(e)}>
                <FormErrors formErrors = {this.state.formErrors} data-type="formError" />
                <Form.Group>
                    <Form.Label className="formLabel">First Name</Form.Label>
                    <Form.Control type="firstName"
                    required
                    placeholder="Enter First Name" 
                    name = "firstName" 
                    onChange = {this.handleUserInput} />
                </Form.Group>
                <Form.Group>
                    <Form.Label className="formLabel">Last Name</Form.Label>
                    <Form.Control type="lastName"
                    required
                    placeholder="Enter Last Name" 
                    name = "lastName" 
                    onChange = {this.handleUserInput} />
                </Form.Group>
                <Form.Group>
                    <Form.Label className="formLabel">User Name</Form.Label>
                    <Form.Control type="username"
                    required
                    placeholder="Enter UserName" 
                    name = "username" 
                    onChange = {this.handleUserInput} />
                </Form.Group>
                <Form.Group >
                    <Form.Label className="formLabel">Password</Form.Label>
                    <Form.Control 
                    type="password"
                    required
                    placeholder="Enter Password" 
                    name = "password" 
                    onChange = {this.handleUserInput} />
                </Form.Group>
                <Form.Group >
                    <Form.Label className="formLabel">ReEnter Password</Form.Label>
                    <Form.Control 
                    type="password"
                    required
                    placeholder="ReEnter Password" 
                    name = "reenterPassword" />
                </Form.Group>
                <Button variant="primary" data-type="submitButton" type="submit" className="btn btn-primary btn-lg btn-block submitBtn">
                    Submit
                </Button>
            </Form>
        </div>;
    }
}

export default Register;

