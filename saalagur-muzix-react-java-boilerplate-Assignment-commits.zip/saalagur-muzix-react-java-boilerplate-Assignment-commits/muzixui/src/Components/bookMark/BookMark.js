import React from 'react';
import CardDeck from 'react-bootstrap/CardDeck';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import { removeBookMarkAsync, fetchBookMarkAsync,savePlayListDb} from '../../services/fetchTracksBookMark.service';
import Card from '../card/Card';
import Footer from '../footer/Footer';
import Header from '../header/Header';

class BookMark extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tracks: []
        };
    }

    
    groupalbumsRowWise = tracks => {
        let dataInRows = {};
        const remainder = (tracks.length % 3) > 0 ? 1 : 0;
        const noOfRows = Math.floor(tracks.length/3)+remainder;
        let k = 0;
        for (let i = 1;i <= tracks.length;i++) {
            if (i >= 1  && i % 3 === 0) {
                k++;
                this.addRow(dataInRows, tracks.slice((i-3), i), k);
            }
            if (remainder > 0 && k === (noOfRows-1)) {
                k++;
                this.addRow(dataInRows, tracks.slice(i-1), k);
            }
        }
        return dataInRows;
    }

    addRow = (dataInRows, tracks, rowIndex) => {
        const rowData = Object.assign(dataInRows, { ['row'+rowIndex]: tracks.map((article, i) => <Col key={'row-col-'+i}><Card card={article} {...this.props} removeBookmark ={this.removeBookmark} savePlayList={this.savePlayList} screen="bookmark" /></Col>) });
        return rowData;
    }

    componentDidMount() {
        const { tracks } = this.state;
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        if (this.props.location && this.props.location.state && this.props.location.state.userName) {
            sessionStorage.setItem("userName", this.props.location.state.userName);
        } 
            fetchBookMarkAsync('http://localhost:8765/muzix-manager/api/v1/user/'+sessionStorage.getItem("userName")+'/bookmark/getAll',bearerToken)
            .then(res => {
                if(res && res.length > 0) {
                    let localAlb = [];
                    res.forEach(function(r1, i) { 
                        if(r1.music!=null){
                            r1.music.bookMarkId = r1.bookMarkId;
                            localAlb.push(r1.music)
                        }
                    });
                    this.setState({ tracks: localAlb });
                }
            })
            .catch(error => {
                console.log('Error in fetching News Headlines:: ', error);
            })       
    }

    removeBookmark = (track) => {
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
            sessionStorage.setItem("authToken", bearerToken);
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        if (this.props.location && this.props.location.state && this.props.location.state.userName) {
            sessionStorage.setItem("userName", this.props.location.state.userName);
        }
        const { tracks } = this.state;
        const updatedTracts = [...tracks];
        removeBookMarkAsync('http://localhost:8765/muzix-manager/api/v1/user/'+sessionStorage.getItem("userName")+'/bookmark/'+track.bookMarkId,bearerToken)
        .then(res => {
            const trackUpdated = updatedTracts.findIndex(track1 => (track.bookMarkId == track1.bookMarkId));
            updatedTracts.pop(trackUpdated);
            this.setState({ tracks: updatedTracts});
        })
    }

    savePlayList = (track,playListName) =>{
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        let playList = {};
        let plTracks = [];
        playList.userId = sessionStorage.getItem("userName");
        playList.playListName = playListName;
        plTracks.push(track);
        playList.tracks = plTracks;
        savePlayListDb('http://localhost:8765/muzix-manager/api/v1/user/'+playList.userId+'/playlist', playList, bearerToken)
        .then(res => {
            
        })
        .catch(error => {
            console.log('Error in saving News Headlines:: ', error);
            return Promise.reject(error);
        })
        return true;

    }

    render() {
        const { tracks } = this.state;
        const updatedTracts = [...tracks];
        const rowWiseData = this.groupalbumsRowWise(updatedTracts);
        return <div>
            <Container className="cardsContainer">
             <Row className = "row-header">
                <Header isReadNow={true} {...this.props} />
            </Row>
            <CardDeck data-foo="cardDeck">
                {Object.keys(rowWiseData).map((rowData, i) => <Row key={'row-'+i} data-foo="cardsRow">{rowWiseData[rowData]}</Row> )}
            </CardDeck>
            <Row className = "row-footer">
                <Footer></Footer>
            </Row>
            </Container>
        </div>;
    }
}

export default BookMark;