import React from 'react';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import DialogBox from '../dashboard/DialogBox';
class DisplayCard extends React.Component {
    render() {
        const { card } = this.props;
        const { screen } = this.props;
        if (card != null) {
            return <Card size= 'lg' data-type="newsCard" bg='light' style={{ margin: '1rem',width: '18rem' }}>
            { (screen == "playlist" )?<Card.Header>{card.playListName}</Card.Header>: ''}
            <Card.Img variant="top" src={card.imageUrl ? card.imageUrl : ''} /> 
            <Card.Body>
                <Card.Title>
                    <Button variant="link" >
                        <a href={card.link} target="_blank" alt="Click Here">
                            {card.name ? card.name.length >20? card.name.substring(0,20)+"..": card.name : ''}
                        </a>
                        </Button>{' '}  { (screen == "playlist" )? <Button size='sm' onClick={() => this.props.removeFromPlaylist(card)}><span>&minus;</span></Button>:<DialogBox track={card} savePlayList={this.props.savePlayList} />}
                </Card.Title>
                <Card.Text>
                    {card.text}
                </Card.Text>
                { (screen == "dashboard" || screen == "recommendation")? <Button size='sm' variant="primary" onClick={() => this.props.bookMarkTrack(card)} data-bookMarkTrack="bookMarkTrack" disabled={card.bookMarked}>{'BookMark'}</Button>: (screen == "bookmark")? <Button size='sm' variant="primary" onClick={() => this.props.removeBookmark(card)} data-bookMarkTrack="bookMarkTrack" disabled={card.bookMarked}>{'Remove'}</Button>: ''} 
            </Card.Body>
            </Card>
             
                        
        }
        return null;
    }    
}

export default DisplayCard;