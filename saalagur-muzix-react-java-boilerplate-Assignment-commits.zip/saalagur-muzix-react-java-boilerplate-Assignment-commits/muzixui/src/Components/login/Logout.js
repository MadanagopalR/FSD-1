import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import Button from 'react-bootstrap/Button';

class Logout extends Component{
    constructor(){
        super();
        this.state = {
            navigate: false
        };
        this.logout = this.logout.bind(this);
    };
    logout = ()  => {
        sessionStorage.removeItem("authToken");
        sessionStorage.removeItem("userName");
        this.setState({navigate:true});
      }

      render(){
          const {navigate} = this.state;
          if(navigate){
              return <Redirect to="/" push={true}></Redirect>
          }

          return <Button variant="link" onClick={this.logout}>Logout</Button>;
      }
}

export default Logout;
