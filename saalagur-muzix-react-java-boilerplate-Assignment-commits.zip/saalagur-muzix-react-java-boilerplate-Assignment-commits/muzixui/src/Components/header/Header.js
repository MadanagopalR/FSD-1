import React from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import Form from 'react-bootstrap/Form';
import FormControl from 'react-bootstrap/FormControl';
import Button from 'react-bootstrap/Button';
import Image from 'react-bootstrap/Image';
import Logout from '../login/Logout'



class Header extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            name :''
        }
    }
    handleSearch = () =>  {
        this.props.filterTracksOnSearch(this.state.name);
        console.log("Called!!!!!!!!!");
    };
    handleUserInput = (e) => {
        let value = e.target.value;
        this.setState({name:value});
    }
    render(){
        return <div>  <Navbar bg="dark" variant="dark" expand="lg" fixed="top" data-navbar="navbar" className="navBar">
            <Navbar.Brand>
                <Image src="./profile.png" roundedCircle />
            </Navbar.Brand>
            <Nav className="mr-auto">
                <Nav.Link href="/dashboard">Home</Nav.Link>
                <Nav.Link href="/bookmark">BookMarks</Nav.Link>
                <Nav.Link href="/PlayList">PlayList</Nav.Link>
                <Nav.Link href="/musicRecommendations">Recommendations</Nav.Link>
            </Nav>
            <Form inline>
            <FormControl type="text" placeholder="Search" className="mr-sm-2" name="search" onChange = {this.handleUserInput}/>
                <Button variant="outline-info" onClick = {this.handleSearch}>Search</Button>
            <Logout></Logout>

            </Form>
      </Navbar>
      </div>
    }


    
}

export default Header;