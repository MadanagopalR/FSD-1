import React from 'react';
import CardDeck from 'react-bootstrap/CardDeck';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import {fetchRecommendations,fetchTracksByArtist,savePlayListDb,saveBookMarkAsync} from '../../services/fetchTracksBookMark.service';
import Card from '../card/Card';
import Footer from '../footer/Footer';
import Header from '../header/Header';

class Recommendation extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tracks: []
        };
    }

    transformAlbumData = (tracks,item) => {
        return tracks.map(track => {
            return { name: track.name, imageUrl: track.image[2]["#text"] == ""?"https://lastfm.freetls.fastly.net/i/u/174s/2a96cbd8b46e442fc41c2b86b821562f.png":track.image[2]["#text"]  ,  artistName: item,link:track.url,bookMarked:track.bookMarked?true:false,text: track.name }
        })
    }

    groupalbumsRowWise = tracks => {
        let dataInRows = {};
        const remainder = (tracks.length % 3) > 0 ? 1 : 0;
        const noOfRows = Math.floor(tracks.length/3)+remainder;
        let k = 0;
        for (let i = 0;i < tracks.length;i++) {
            if (i > 0 && i % 3 === 0) {
                k++;
                this.addRow(dataInRows, tracks.slice((i-3), i), i);
            }
            if (remainder > 0 && k === (noOfRows-1)) {
                k++;
                this.addRow(dataInRows, tracks.slice(i), i+1);
            }
        }
        return dataInRows;
    }

    addRow = (dataInRows, tracks, rowIndex) => {
        const rowData = Object.assign(dataInRows, { ['row'+rowIndex]: tracks.map((article, i) => <Col key={'row-col-'+i}><Card card={article} {...this.props} bookMarkTrack={this.bookMarkTrack} savePlayList={this.savePlayList}  screen = "recommendation" isReadNow={true} /></Col>) });
        return rowData;
    }

    componentDidMount() {
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        if (this.props.location && this.props.location.state && this.props.location.state.userName) {
            sessionStorage.setItem("userName", this.props.location.state.userName);
        }  
        fetchRecommendations('http://localhost:8765/muzix-recommendation/api/v1/user/'+sessionStorage.getItem("userName")+'/recommendations',bearerToken)
            .then(res => {
                if(res && res.length > 0) {
                    let mySet = new Set();
                    res.forEach(function(r1, i) { 
                        mySet.add(r1.artistName);
                    });
                    let localAlb = [];
                    for (let item of mySet) 
                    {
                        fetchTracksByArtist(bearerToken,item)
                        .then(recTracks => {
                            if(recTracks && recTracks.length > 0) {
                                localAlb.push(...recTracks);
                                this.setState({ tracks: this.transformAlbumData(localAlb,item) });
                            }
                        });
                    }
                   
                }
            })
            .catch(error => {
                console.log('Error in fetching News Headlines:: ', error);
            })
                
    }

    bookMarkTrack = (track) => {
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
            sessionStorage.setItem("authToken", bearerToken);
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        let bookMark = {};
        bookMark.userId = sessionStorage.getItem("userName");
        bookMark.music = track;
        saveBookMarkAsync('http://localhost:8765/muzix-manager/api/v1/user/'+bookMark.userId+'/bookmark', bookMark, bearerToken)
        .then(res => {
            const { tracks } = this.state;
            const updatedTracts = [...tracks];
            const trackUpdated = updatedTracts.find(track1 => (track.name == track1.name && track.artistName == track1.artistName));
            trackUpdated.bookMarked = true;
            this.setState({ tracks: updatedTracts})

        })
        .catch(error => {
            console.log('Error in saving News Headlines:: ', error);
            return Promise.reject(error);
        })
    }

    savePlayList = (track,playListName) =>{
        let bearerToken = '';
        if (this.props.location && this.props.location.state && this.props.location.state.tokenResponse) {
            bearerToken = this.props.location.state.tokenResponse;
            bearerToken = bearerToken.token ? bearerToken.token : '';
        }
        bearerToken = !bearerToken ? sessionStorage.getItem("authToken") : bearerToken;
        let playList = {};
        let plTracks = [];
        playList.userId = sessionStorage.getItem("userName");
        playList.playListName = playListName;
        plTracks.push(track);
        playList.tracks = plTracks;
        savePlayListDb('http://localhost:8765/muzix-manager/api/v1/user/'+playList.userId+'/playlist', playList, bearerToken)
        .then(res => {
            
        })
        .catch(error => {
            console.log('Error in saving News Headlines:: ', error);
            return Promise.reject(error);
        })
        return true;

    }

    render() {
        const { tracks } = this.state;
        const rowWiseData = this.groupalbumsRowWise(tracks);
        return <div>
            <Container className="cardsContainer">
             <Row className = "row-header">
                <Header isReadNow={true} {...this.props} />
            </Row>
            <CardDeck data-foo="cardDeck">
                {Object.keys(rowWiseData).map((rowData, i) => <Row key={'row-'+i} data-foo="cardsRow">{rowWiseData[rowData]}</Row> )}
            </CardDeck>
            <Row className = "row-footer">
                <Footer></Footer>
            </Row>
            </Container>
        </div>;
    }
}

export default Recommendation;